﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedModels
{
    public class Producto
    {
        [Key]
        public int ProductId { get; set; }
        [StringLength (100)]
        public string? Name { get; set; }
        [StringLength(100)]
        public string? Description { get; set; }
        public DateOnly CreatedAt { get; set; }
        public int CategoryId { get; set; }
        public Category? Category { get; set; }
    }
}
