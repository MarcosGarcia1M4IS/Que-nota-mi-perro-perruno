﻿using Microsoft.EntityFrameworkCore;
using SharedModels;

namespace Product.Data
{
    public class ProductContext : DbContext
    {
        public ProductContext(DbContextOptions<ProductContext> options) :
           base(options)
        {

        }

        public DbSet<Category> Categorys { get; set; }
        public DbSet<Producto> Productos { get; set; }
    }
}
