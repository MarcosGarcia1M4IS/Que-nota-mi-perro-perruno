﻿using SharedModels;

namespace Product.Repository.IRepository
{
    public interface IProductoRepository : IRepository<Producto>
    {
        Task<Producto> UpdateAsync(Producto entity);
    }
}
