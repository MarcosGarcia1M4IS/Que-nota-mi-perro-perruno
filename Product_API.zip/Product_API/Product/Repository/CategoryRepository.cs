﻿using Microsoft.EntityFrameworkCore;
using Product.Data;
using Product.Repository.IRepository;
using SharedModels;

namespace Product.Repository
{
    public class CategoryRepository : Repository<Category>, ICategoryRepository
    {
        private readonly ProductContext _context;

        public CategoryRepository(ProductContext context) : base(context)
        {
            _context = context;
        }
        public async Task<Category> UpdateAsync(Category entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return entity;
        }
    }
}
