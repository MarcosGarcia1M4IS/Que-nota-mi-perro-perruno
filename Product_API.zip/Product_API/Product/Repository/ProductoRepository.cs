﻿
using Microsoft.EntityFrameworkCore;
using Product.Data;
using Product.Repository.IRepository;
using SharedModels;

namespace Product.Repository
{
    public class ProductoRepository : Repository<Producto>, IProductoRepository
    {
        private readonly ProductContext _context;

        public ProductoRepository(ProductContext context) : base(context)
        {
            _context = context;
        }

        public async Task<Producto> UpdateAsync(Producto entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return entity;
        }
    }
}
