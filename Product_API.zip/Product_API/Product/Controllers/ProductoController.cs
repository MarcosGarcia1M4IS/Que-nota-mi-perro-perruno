﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Product.Repository.IRepository;
using SharedModels;
using SharedModels.Dto;

namespace Product.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class ProductoController
    {
        private readonly ICategoryRepository _categoryRepo;
        private readonly IProductoRepository _productoRepo;
        private readonly ILogger<ProductoController> _logger;
        private readonly IMapper _mapper;

        public ProductoController (ICategoryRepository categoryRepo, IProductoRepository productoRepo, ILogger<ProductoController> logger, IMapper mapper)
        {
            _categoryRepo = categoryRepo;
            _productoRepo = productoRepo;
            _logger = logger;
            _mapper = mapper;
        }

       
    }
}
