﻿using System.Runtime.CompilerServices;
using AutoMapper;
using SharedModels.Dto;
using SharedModels;
namespace Product
{
    public class MappingConfig : Profile
    {
       public MappingConfig() 
       {
            CreateMap<Producto, ProductDto>().ReverseMap();
            CreateMap<Producto, ProductCreateDto>().ReverseMap();
            CreateMap<Producto, ProductUpdateDto>().ReverseMap();
            CreateMap<Category, CategoryDto>().ReverseMap();
            CreateMap<Category, CategoryCreateDto>().ReverseMap();
            CreateMap<Category, CategoryUpdateDto>().ReverseMap();

        }
    }
}
